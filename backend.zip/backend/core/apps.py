from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'

    def ready(self):
        from core.backup_scheduler import try_start_backup_scheduler

        try_start_backup_scheduler()
